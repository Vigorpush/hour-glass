# Hourglass
A Fast Paced Tactics Game
---
#TeamMembers
|Name|NSID|
|-------|--------|
|JiaWei Zang|JIZ457|
|Justin Schneider|JHS507|
|Parker Neufeld|PDN844|
|Matt Collison|MSC263|
|Liam Balan|LGB621|

## Project OverView

1.A tactics style combat game  
2.Set in a fantasy setting  
3.Has QTE based attack combos  
4.Time is used as a resource  
5.Inspired by:  
      &nbsp;&nbsp;&nbsp;&nbsp;     Fire Emblem  
      &nbsp;&nbsp;&nbsp;&nbsp;     Final Fantasy  
      &nbsp;&nbsp;&nbsp;&nbsp;     Rhythm Games  
=======
# CMPT306-RPG-GAME-PROJECT
RPG GAME Project



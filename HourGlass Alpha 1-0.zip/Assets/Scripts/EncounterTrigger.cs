﻿using UnityEngine;
using System.Collections;

public class EncounterTrigger : MonoBehaviour
{


    void Start()
    {

    }
}

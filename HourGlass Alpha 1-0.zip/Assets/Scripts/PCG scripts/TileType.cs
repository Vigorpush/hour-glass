﻿using System;


	//Tile Type
	public enum TileType {
	wall, floor, obsticle, encounter, hallFloor, goal,
	}



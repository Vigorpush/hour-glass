﻿using System;


	public enum Direction
	{
		North, East, South, West,
	}



﻿using UnityEngine;
using System.Collections;

public class UnitAI : MonoBehaviour {

	// Use this for initialization


}

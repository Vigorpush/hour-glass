﻿using UnityEngine;
using System.Collections;

public interface IRangeAttack  {
	DecisionTree buildRangedTree();


}

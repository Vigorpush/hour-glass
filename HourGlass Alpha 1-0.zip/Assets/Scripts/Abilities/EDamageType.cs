﻿using UnityEngine;
using System.Collections;

public enum EDamageType {
	PHYSICAL = 0,
	FIRE = 1,
	HOLY = 2,
	ARCANE =3,

}

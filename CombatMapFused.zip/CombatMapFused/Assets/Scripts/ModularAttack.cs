﻿using UnityEngine;
using System.Collections;

public class BasicAttack : MonoBehaviour {
	Vector3 origin;
	GameObject target;
	int range;
	//Ray Shape Type

	//effect class?

	// Use this for initialization
	void Start () {
	
	}
	void attack1(){


	}
	// Update is called once per frame
	void Update () {
	
	}



}

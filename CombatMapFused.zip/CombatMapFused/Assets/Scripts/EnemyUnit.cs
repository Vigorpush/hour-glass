﻿using UnityEngine;
using System.Collections;

public class EnemyUnit : Unit {

    //remove the start method to avoid override stats

}

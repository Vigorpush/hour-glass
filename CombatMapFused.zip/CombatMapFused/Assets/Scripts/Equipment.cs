﻿using UnityEngine;
using System.Collections;

public class Equipment : MonoBehaviour {

    public string type;
    public int value;
    public string rarity;

}

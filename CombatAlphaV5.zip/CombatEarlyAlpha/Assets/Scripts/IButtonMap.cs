﻿using UnityEngine;
using System.Collections;

public interface IButtonMap {

	// Use this for initialization

}

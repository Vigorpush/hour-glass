﻿/*
using UnityEngine;
using System.Collections;

public class TargetScan : MonoBehaviour, IRayCast  {
	public Transform tf;
	public Vector3 pos;
	void Start(){
		tf = GetComponent<Transform> ();
		pos = tf.position;

	}
	public RaycastHit2D rayCheckLine(int length){
		
	}


}
*/
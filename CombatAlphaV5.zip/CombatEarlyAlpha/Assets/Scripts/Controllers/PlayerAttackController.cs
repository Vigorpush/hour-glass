﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
[System.Serializable]
public class PlayerAttackController : MonoBehaviour {

	private const int NUMBER_OF_ABILITIES = 4;
	//Dummy action for when less skills are mapped
	public bool[] emptySlots = new bool[NUMBER_OF_ABILITIES]; 
	// Find the collection library public Hashtable<string,Abiity> playerAbilities;
	public List<AttackTemplate> activeAbilities;
	public bool allowAttack;
	//public bool AllowAttack { get { return allowAttack; } set { allowAttack = value;} }
	//public BasicAttack test;
	public HeroUnit myHero;
	// Use this for initialization
	private Animator anim;
   private List<RaycastHit2D> thisAttackTargets;
   private List<KeyCode> theInputButtons;
   private int[] damageValues;
    private bool inputActivated;
    private bool abilityIsASpell;
    private GameObject cam;

    /*public GameObject ability1;
	public GameObject ability2;
	public GameObject ability3;
	public GameObject ability4;*/

    private bool baseButtons;
	private bool hasBaseAttack;

    public void setAttackTargets(List<RaycastHit2D> listIn)
    {
        if (listIn.Count <= 0)
        {
           // Debug.Log(this.gameObject.name + "'s Attack controller told no targets");
            anim.SetTrigger("Attack1");
            anim.SetTrigger("ComboFail");
            this.gameObject.GetComponent<PlayerMovement>().EndTurn();
            return;
        }
        else {
            cam.GetComponent<CameraFollow>().SetCameraFollow(this.gameObject);
            thisAttackTargets = listIn;
            //Debug.Log(thisAttackTargets.Count);
                this.gameObject.GetComponent<ComboController>().BeginComboInput(theInputButtons, thisAttackTargets, damageValues,abilityIsASpell);
            
        }
    }

	void Start () {
        //activeAbilities = new List<BasicAttack> ();
        //activeAbilities.Insert (0,test);
        //Debug.Log (activeAbilities.ToString());
        cam = GameObject.FindGameObjectWithTag("MainCamera");
		myHero = GetComponent<HeroUnit> (); //!
		anim = GetComponent<Animator> ();
		setEmptySlots ();
        abilityIsASpell =false;
        if (emptySlots [0] == true) {
			hasBaseAttack=false;
		}
        thisAttackTargets = new List<RaycastHit2D>();

		//On build get 3 active abilities and 1 basic attack   //Implies that wait, defend are the same all the time
		baseButtons = true;	

	}

	/*void AllowAttack(){
		allowAttack = true;

		//attackController = GetComponent<PlayerAttackController> ();
		//AllowMovement();
		//attackController.AllowAttack = true;
		Debug.Log( "I, " + this.gameObject.name + " Started turn and can attack.");

	}
	*/
	void setEmptySlots(){
		int i = 0;

		activeAbilities.ForEach(delegate(AttackTemplate ab) 
		{
				if(ab == null){

					emptySlots[i]=true;
				}
				i++;
		});
		if (activeAbilities [0] == null) {
			hasBaseAttack = false;
		}

        //This is needed so each game object does not share the same basic attack!!!
        //Do this for all abilities, do not use unity inspector to drag in abilities for now.
        activeAbilities[0] = this.gameObject.AddComponent<BasicAttack>();
        activeAbilities[1] = this.gameObject.AddComponent<BasicRayAttack>();

	}
	//Basic = 0, A1=1 ....
	void Update (){
        if (inputActivated) {
            //WHEN CAN USE SPECIAL ABILITIES
            if (allowAttack) {
                if (!baseButtons) {
                    if (Input.GetKeyDown(KeyCode.Alpha1) && emptySlots[1] == false) {//if (Input.GetButtonDown ("AButton") && emptySlots [1] == false) {
                        ExecuteAbility(activeAbilities[1]);
                    }
                    if (Input.GetKeyDown(KeyCode.Alpha2) && emptySlots[2] == false) {//if (Input.GetButtonDown ("XButton") && emptySlots [2] == false) {
                        ExecuteAbility(activeAbilities[2]);
                    }
                    if (Input.GetKeyDown(KeyCode.Alpha3) && emptySlots[3] == false) {
                        ExecuteAbility(activeAbilities[3]);
                    }
                } else {
                    //WHEN USING NORMAL ABILITIES
                    if (Input.GetKeyDown(KeyCode.Alpha1) && hasBaseAttack == false) {
                        //0 is used because
                        //Debug.Log ("press 1");
                        ExecuteAbility(activeAbilities[0]);
                        //anim.SetTrigger ("Attack1");
                    }
                    if (Input.GetKeyDown(KeyCode.Alpha2)) {
                        //myHero.SendMessage ("WaitAction"); //this is what alpha2 should actually do, ray hardcoded
                        ExecuteAbility(activeAbilities[1]);
                    }
                    if (Input.GetKeyDown(KeyCode.Alpha3)) {
                        myHero.SendMessage("FortifyAction");
                    }
                }
                if (Input.GetKeyDown(KeyCode.Alpha4)) {
                    switchButtonInput();
                }
            }
        }
	}
	public  void switchButtonInput(){
		baseButtons = !baseButtons;
    }
						
	void stopMovement(){
		SendMessage ("UnAllowMovement");
	}


	public void ExecuteAbility(AttackTemplate ability){

        if (ability.hasASpellAnimation)
        {
            abilityIsASpell = true;
        }
        else
        {
            abilityIsASpell = false;
        }

		allowAttack = false;
        stopMovement();
        theInputButtons =ability.GetComboInputSequence();
        damageValues = ability.GetDamageSteps();

        ability.CheckLine(); //start aquiring targets
        disableAttackInput();

			
	}

    public void enableAttackInput()
    {
        Invoke("enableAfterBuffer",0.5f);
    }

    public void enableAfterBuffer()
    {
        inputActivated = true;
       // Debug.Log("Listening for attack input from :" +this.gameObject.name);
    }

    public void disableAttackInput()
    {
        inputActivated = false;
    }


}




﻿using UnityEngine;
using System.Collections;

public class HeroUnit :  Unit, IButtonMap  {

    //remove the start method to avoid override stats
	/*Todo  list of  skill points / maybe seperate passives
	 * mapping of active abilities public to allow drag drop prefabs
	 * 
	 * 
	 */

    
}

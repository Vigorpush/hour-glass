﻿using UnityEngine;
using System.Collections;

public class EnemyUnit : Unit {



	// Use this for initialization
	
}
